﻿using SecureWebApiEg.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Web;

namespace SecureWebApiEg
{
    public class APIKeyHandler:DelegatingHandler
    {
        protected override System.Threading.Tasks.Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, System.Threading.CancellationToken cancellationToken)
        {
            //var queryString = request.RequestUri.ParseQueryString();
            //var apiKey = queryString["apiKey"];

            var apiKey = request.Headers.GetValues("apiKey").FirstOrDefault();

            WebAPISecurityDBEntities WE = new WebAPISecurityDBEntities();
            var userObj = WE.APIUsers.Where(x => x.APIUserKey.ToString() == apiKey).FirstOrDefault();

            if (userObj != null)
            {
                var username = userObj.APIUserName;

                var principal = new ClaimsPrincipal(new GenericIdentity(username, "APIKey"));
                HttpContext.Current.User = principal;

                return base.SendAsync(request, cancellationToken);
            }
            //else
            //{
            //    var tsc = new TaskCompletionSource<HttpResponseMessage>();
            //    var response = new HttpResponseMessage(HttpStatusCode.Forbidden);
            //    tsc.SetResult(response);
            //    return tsc.Task;
            //}
            return base.SendAsync(request, cancellationToken);
        }
    }
}