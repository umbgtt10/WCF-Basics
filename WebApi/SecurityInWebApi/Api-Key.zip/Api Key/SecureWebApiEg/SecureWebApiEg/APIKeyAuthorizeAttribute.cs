﻿using SecureWebApiEg.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace SecureWebApiEg
{
    public class APIKeyAuthorizeAttribute:AuthorizeAttribute
    {
        public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            var actionRole = Roles[0].ToString();
            var userName = HttpContext.Current.User.Identity.Name;
            WebAPISecurityDBEntities WE = new WebAPISecurityDBEntities();
            var userObj = WE.APIUsers.Where(x => x.APIUserName == userName).FirstOrDefault();

            if (userObj != null)
            {
                var userRole = userObj.APIUserRole;
                if (actionRole == userRole)
                {

                }
            }
            else
            {
                actionContext.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
            }
        }
    }
}